import { Position } from "./Position.js";

export class TimePosition {
    constructor({
        position,
        timestamp, 
        received, 
        expiry}
    ){
        this.position = position;
        this.timestamp = timestamp;
        this.received = received;
        this.expiry = expiry;
    }

    static fromJSON(jsonString) {
        return new TimePosition({
            position: new Position(
                jsonString.longitude, 
                jsonString.latitude, 
                jsonString.easting, 
                jsonString.jsonString,
                jsonString.bearing
            ),
            timestamp: jsonString.datetime_utc,
            received: new Date().toISOString().replace('Z', ''),
            expiry: jsonString.expiry_time,
        })
    }

    getLonLat() {
        return this.position.getLonLat();
    }
}
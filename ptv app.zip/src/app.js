import { initMap } from './map/initMap.js';
import { drawTrainLines, drawStops, drawVehicle } from './map/draw.js';
import { callPTVAPI } from './api/ptvApi.js';
import { Queue } from './models/Queue.js';
import { fetchRuns, updateVehiclePositionLoop } from './api/update.js';
import { TRAIN_LINES } from './config/trainLines.js'; 
import { interpolationLoop } from './api/update.js';


async function main() {

    console.log("Starting");
    const map = await initMap();
    console.log("Map loaded")
    
    console.log("Drawing features")
    const SELECTED_LINES = TRAIN_LINES.map(line => line.code); 
    // const SELECTED_LINES = ['CGE']; 
    map.on('load', async () => {
        await drawTrainLines(map, TRAIN_LINES, SELECTED_LINES)
        drawStops(map, 'data/railway_stations.geojson', 'train-stations')
        await drawVehicle(map)
    });
    // let response = await callPTVAPI("runs", 967031)
    // console.log(response)
    let trainQueue = new Queue(vehicle => vehicle.currPos.expiry);
    let busQueue = new Queue(vehicle => vehicle.currPos.expiry);
    let tramQueue = new Queue(vehicle => vehicle.currPos.expiry);
    let vlineQueue = new Queue(vehicle => vehicle.currPos.expiry);
    await fetchRuns(trainQueue, TRAIN_LINES.map(line => line.id), 0);
    // await fetchRuns(trainQueue, [3], 0);
    // await updateRuns(busQueue, [15614], 2);
    console.log(trainQueue.toString());
    console.log(trainQueue.size());
    // updateVehiclePosition(map, trainQueue.heap);
    updateVehiclePositionLoop(trainQueue);
    interpolationLoop(trainQueue);
    animationLoop(map, trainQueue);

    // console.log(map.getSource("vehicle-positions"))



}

function updateVehiclePosition(map, vehicleList) {
    
    const source = map.getSource('vehicle-positions');
    if (!source) {
        console.error('Source "vehicle-positions" not found.');
        return;
    }
    const geojson = {
        type: "FeatureCollection",
        features: vehicleList.map(vehicle => ({
            type: "Feature",
            geometry: {
                type: "Point",
                coordinates: vehicle.getDispLonLat()
            },
            properties: {
                color: vehicle.lineColor,
                label: vehicle.lineCode
            }
        }))
    }
    map.getSource('vehicle-positions').setData(geojson)
}

async function animationLoop(map, vehicleQueue) {
    while (true) {
        await updateVehiclePosition(map, vehicleQueue.heap);
        await sleep(100);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function vehicleInfoPopup(map, vehicleList) {
    let popup = null;
    map.on("mouseenter", "vehicle-layer", (e) => {
        map.getCanvas().style.cursor = "pointer";
        const feature = e.features[0]
    })
}

main();
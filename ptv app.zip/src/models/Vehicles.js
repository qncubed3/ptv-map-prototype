import { Position } from '../models/Position.js';
import { TimePosition } from '../models/TimePosition.js';
import { TRAIN_LINES } from '../config/trainLines.js';
import { LINE_COLORS } from '../config/colors.js';

export class Vehicle {
    constructor({
        runRef,
        routeId,
        routeType,
        destName,
        dirId,
        currPos,
        prevPos,
        dispPos,
    }) {
        
        if (!(currPos instanceof TimePosition)) {
            throw new TypeError("currPos must be a TimePosition instance");
        }

        if (prevPos != null && !(prevPos instanceof TimePosition)) {
            throw new TypeError("prevPos must be a TimePosition instance");
        }

        if (dispPos != null && !(dispPos instanceof Position)) {
            throw new TypeError("dispPos must be a Position instance");
        }

        // Basic info
        this.runRef = runRef;
        this.routeId = routeId;
        this.routeType = routeType;
        this.destName = destName;
        this.dirId = dirId;
        this.currPos = currPos;
        this.prevPos = prevPos;
        this.dispPos = dispPos;

        // Line info
        if (routeType == 0) {
            const trainLine = TRAIN_LINES.find(line => line.id === this.routeId.toString());
            this.lineName  = trainLine ? trainLine.name  : 'None';
            this.lineCode  = trainLine ? trainLine.code  : 'None';
            this.lineColor = trainLine ? trainLine.color : 'rgba(0, 0, 0, 1)';
        } else if (routeType == 2) {
            this.lineColor = LINE_COLORS.ORANGE;
            this.lineCode = "BUS";
            this.lineName = "BUS";
        }
    }


    static fromJSON(jsonData) {
        const curr = TimePosition.fromJSON(jsonData.vehicle_position);
        return new Vehicle({
            runRef: jsonData.run_ref,
            routeId: jsonData.route_id,
            routeType: jsonData.route_type,
            destName: jsonData.destination_name,
            dirId: jsonData.direction_id,
            currPos: curr,
            prevPos: curr,
            dispPos: curr.position
        });
    }

    getCurrLonLat() {
        return this.currPos.getLonLat();
    }

    getPrevLonLat() {
        return this.prevPos.getLonLat();
    }

    getDispLonLat() {
        if (!this.dispPos) {
            console.log("BRUH");
            
            return this.currPos.getLonLat();
        }
        return this.dispPos.getLonLat();
    }

    setDispLonLat(lonLatArray) {
        if (!this.dispPos) {
            this.dispPos = Position.fromLonLat(lonLatArray);
        }
        this.dispPos.setLonLat(lonLatArray);
    }



    async update() {
        response = await callPTVAPI("runs", this.runRef)
    }

    updatePosition(newPos) {
        if (!(newPos instanceof Position)) {
            throw new TypeError("newPos must be a Position instance");
        }

        this.prevPos = this.currPos;
        this.currPos = newPos;
        this.lastUpdateTimestamp = Date.now();
    }

    hasMoved() {
        if (!this.prevPos) return true;
        return this.currPos.distanceTo(this.prevPos) > 0;
    }

    info() {
        console.log(
            `Vehicle ${this.runRef} at ${this.currPos.toString()} `
            + `(updated ${new Date(this.lastUpdateTimestamp).toLocaleTimeString()})`
        );
    }

    toString() {
        return `\n${this.runRef}, ${this.currPos.expiry}, ${this.currPos.position.longitude}, ${this.currPos.position.latitude}` ;
    }
}
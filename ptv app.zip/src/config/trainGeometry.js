export const TRAIN_GEOJSON_FILES = [
    'alamein.geojson',
    'belgrave.geojson',
    'glen-waverley.geojson',
    'lilydale.geojson',
    'craigieburn.geojson',
    'sunbury.geojson',
    'upfield.geojson',
    'cranbourne.geojson',
    'pakenham.geojson',
    'hurstbridge.geojson',
    'mernda.geojson',
    'sandringham.geojson',
    'frankston.geojson',
    'werribee-edit.geojson',
    'williamstown.geojson'
];

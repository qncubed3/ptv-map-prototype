export const STATIONS = {
    path: 'data/railway_stations.geojson',
    style: {
        radius: 8,
        color: 'rgba(100, 100, 100, 0.7)',
        strokeWidth: 1,
        strokeColor: 'white'
    }
};
import sys
import json
import hmac
import hashlib
import urllib.request
import json
import urllib.parse
from datetime import datetime
from zoneinfo import ZoneInfo

# Your credentials
DEV_ID = open("data/ptv_api_id.txt").read().strip()
API_KEY = open("data/ptv_api_key.txt").read().strip()
BASE_URL = 'https://timetableapi.ptv.vic.gov.au'

ROUTE_TYPE = {"train":0,"tram":1,"bus":2,"vline":3}


def build_ptv_url(endpoint, params={}, devid=DEV_ID, key=API_KEY, base_url=BASE_URL):
    """
    endpoint: string, e.g. "/v3/route_types"
    params: dict of other query parameters (excluding devid & signature)
    devid: your developer id (string or int)
    key: your API key (string)
    """
    # Build query string (excluding signature)
    params = params.copy()
    params['devid'] = devid
    # sort params optionally to ensure consistent ordering
    # but PTV may not require alphabetical order — just be consistent
    query = urllib.parse.urlencode(params)
    uri = f"{endpoint}?{query}"
    
    # signature calculation: HMAC‑SHA1 of `uri` using key
    # key must be bytes, uri must be bytes (UTF‑8)
    signature = hmac.new(key.encode('utf‑8'),
                         uri.encode('utf‑8'),
                         hashlib.sha1).hexdigest().upper()
    
    # Build full URL
    full_url = f"{base_url}{uri}&signature={signature}"
    return full_url

def send_request(endpoint, params, devid=DEV_ID, key=API_KEY, base_url=BASE_URL):
    url = build_ptv_url(endpoint, params, devid=devid, key=key, base_url=base_url)
    print(url)

    try:
        with urllib.request.urlopen(url) as resp:
            status = resp.getcode()          # HTTP status code
            data = resp.read()               # raw bytes
            text = data.decode("utf-8")      # convert bytes → str
            body = json.loads(text)          # parse JSON
    except Exception as e:
        print("Error calling API:", e)
        return None, url

    if status == 200:
        return body, url
    else:
        print(f"Error {status}: {text}")
        return None, url



def get_stop_id(search_term, route_type=0):
    endpoint = f"/v3/search/{search_term}"
    params   = {"route_types": route_type}
    response, url = send_request(endpoint, params)
    if not response:
        return
    return json.dumps([stop for stop in response["stops"]], indent=4)

def get_routes(route_type="0", route_id="", only_ids=False):
    print(route_id)
    # route_type = int(route_type) if route_type.isdigit() else ROUTE_TYPE.get(route_type.lower(), -1)

    
    endpoint = f"/v3/routes/{route_id}"
    params   = {"route_types": route_type}
    response, url = send_request(endpoint, params)
    if only_ids:
        return [route.get("route_id") for route in response.get("routes", [])]
    if route_id:
        return json.dumps(response, indent=4)
    else:
        return json.dumps([route for route in response.get("routes", [])], indent=4)
        

def get_departures(route_type=0, stop_id=0, route_id=None):
    endpoint = f"/v3/departures/route_type/{route_type}/stop/{stop_id}"
    endpoint += f"/route/{route_id}" if route_id is not None else ""
    params   = {"route_types": route_type}
    response, url = send_request(endpoint, params)
    print(response)
    for departure in response["departures"]:
        print(
            departure["run_ref"], 
            f"{departure['direction_id']:>2}",
            datetime.strptime(departure["scheduled_departure_utc"], "%Y-%m-%dT%H:%M:%SZ")
                .replace(tzinfo=ZoneInfo("UTC"))
                .astimezone(ZoneInfo("Australia/Melbourne"))
                .strftime("%H:%M")
        )

def get_positions(route_type="0", route_ids=""):
    route_type = int(route_type) if route_type.isdigit() else ROUTE_TYPE.get(route_type.lower(), -1)
    runs = []
    if not route_ids:
        route_ids = get_routes(route_type=route_type, only_ids=True)
    for route_id in route_ids:
        endpoint = f"/v3/runs/route/{route_id}/route_type/{route_type}"
        params   = {"expand": "All"}
        response, url = send_request(endpoint, params)
        for run in response.get("runs", []):
            if run.get("vehicle_position"):
                runs.append(run)
    return json.dumps(runs, indent=4)
    
def get_run_info(run_ref):
    endpoint = f"/v3/runs/{run_ref}"
    params   = {"expand": "All"}
    response, url = send_request(endpoint, params)
    return json.dumps(response, indent=4)   


def process_args(args):
    output = ""
    if len(args) >= 1:
        match args[0]:
            case "routes":
                output = get_routes(route_type=(args[1] if len(args)>1 else 0), route_id=(args[2] if len(args)>2 else ""))
            case "search":
                output = get_stop_id("_".join(args[1:]) if args[1:] else "")
            case "departures":
                output = get_departures(stop_id=args[1], route_id=(args[2] if len(args)>2 else None))
            case "positions":
                output = get_positions(route_type=(args[1] if len(args)>1 else 0), route_ids=(args[2:] if len(args)>2 else 0))
            case "runs":
                output = get_run_info(args[1])
    return output


if __name__ == "__main__":
    output = process_args(sys.argv[1:])
    print(output)
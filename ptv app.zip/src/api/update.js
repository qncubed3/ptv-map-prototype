import { Vehicle } from '../models/Vehicles.js';
import { callPTVAPI } from './ptvApi.js';
import { TimePosition } from '../models/TimePosition.js';

export async function fetchRuns(runQueue, routeIds, routeType) {
    const failed = []; // store routeIds that fail

    const promises = routeIds.map((id, index) => {
        return new Promise(resolve => {
            setTimeout(async () => {
                try {
                    const jsonList = await callPTVAPI("positions", routeType, id);
                    addListOfVehicles(runQueue, jsonList);
                } catch (err) {
                    console.error(`Error fetching route ${id}:`, err);
                    failed.push(id); // add failed route to retry
                }
                resolve();
            }, index * 100); // stagger start
        });
    });

    await Promise.all(promises);

    // Retry failed routes once more
    if (failed.length > 0) {
        console.log(`Retrying failed routes: ${failed.join(", ")}`);
        const retryPromises = failed.map((id, index) => {
            return new Promise(resolve => {
                setTimeout(async () => {
                    try {
                        const jsonList = await callPTVAPI("positions", routeType, id);
                        addListOfVehicles(runQueue, jsonList);
                        console.log(`Retry success for route ${id}`);
                    } catch (err) {
                        console.error(`Retry failed for route ${id}:`, err);
                    }
                    resolve();
                }, index * 200);
            });
        });
        await Promise.all(retryPromises);
    }
}

function addListOfVehicles(runQueue, jsonList) {
    jsonList.forEach(run => {
        runQueue.push(Vehicle.fromJSON(run));
    })
    // console.log(runQueue.toString());
}

async function updateExpiredVehicle(runQueue) {
    if (runQueue.heap.length == 0) {
        return;
    }
    for (let i = 1; i < runQueue.size(); i++) {
        const vehicle = runQueue.heap[i];
        if (new Date(vehicle.currPos.expiry).getTime() < Date.now()) {
            vehicle.prevPos = vehicle.currPos;
            const newJson = await callPTVAPI("runs", vehicle.runRef);
            // If API failed or returned unexpected structure
            if (!newJson || !newJson.runs || newJson.runs.length === 0) {
                console.warn("PTV returned empty run data for", vehicle.runRef, newJson);
                continue;
            }

            const newPos = newJson.runs[0].vehicle_position;

            if (!newPos) {
                console.warn("PTV returned run but no vehicle_position", vehicle.runRef);
                continue;
            }
            vehicle.currPos = TimePosition.fromJSON(newPos);
            // console.log(vehicle.runRef, vehicle.destName);
            runQueue.heap.sort();
        } else {
            break;
        }
    }
}

export async function updateVehiclePositionLoop(runQueue) {
    while (true) {
        await updateExpiredVehicle(runQueue);
        await sleep(1000);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

export async function interpolateVehiclePosition(vehicle) {
    if (!vehicle.currPos) {
        return;
    }
    if (!vehicle.prevPos) {
        vehicle.prevPos = vehicle.currPos;
    }
    const currentTime = Date.now();
    const currPosExpiry = new Date(vehicle.currPos.expiry).getTime();
    const prevPosExpiry = new Date(vehicle.prevPos.expiry).getTime();
    let timeProp = 0;
    if (!(currPosExpiry === prevPosExpiry)) {
        timeProp = (currentTime - prevPosExpiry) / (currPosExpiry - prevPosExpiry);
    }
    if (timeProp < 0) timeProp = 0;
    if (timeProp > 1) timeProp = 1;
    const currLonLat = vehicle.getCurrLonLat();
    const prevLonLat = vehicle.getPrevLonLat();
    
    const dispLonLat = vectorAdd(vectorScale(1 - timeProp, prevLonLat), vectorScale(timeProp, currLonLat));
    // if (vehicle.runRef == 953887) {
    //     console.log(currLonLat, prevLonLat, (currentTime - prevPosExpiry) / (currPosExpiry - prevPosExpiry) , dispLonLat);
    // }
    vehicle.setDispLonLat(dispLonLat);
}

export async function interpolationLoop(runQueue) {
    
    while (true) {
        
        for (let vehicle of runQueue.heap) {
            interpolateVehiclePosition(vehicle);
            
            
        }
        await sleep(50);
    }
}

function vectorAdd(a, b) {
    return [a[0]+b[0], a[1]+b[1]];
}

function vectorScale(k, a) {
    return [k * a[0], k * a[1]];
}
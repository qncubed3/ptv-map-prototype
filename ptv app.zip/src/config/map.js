export const MAP_CONFIG = {
    accessToken: 'pk.eyJ1IjoicW5jdWJlZDMiLCJhIjoiY21ocjk3dTNnMTZ4bzJrcHp6dGJqcWVxMiJ9.dJoDGUOd4gdlA2Rlx-d-Cw',
    container: 'map',
    style: 'mapbox://styles/mapbox/light-v11',
    center: [144.9631, -37.8136],
    zoom: 12,
    maxBounds: [
        [144.5, -38.2],
        [145.5, -37.5]
    ]
};


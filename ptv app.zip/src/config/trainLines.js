import { LINE_COLORS } from './colors.js';

export const TRAIN_LINES = [
    { id: "1", name: "Alamein", code: "ALM", color: LINE_COLORS.BLUE },
    { id: "2", name: "Belgrave", code: "BEG", color: LINE_COLORS.BLUE },
    { id: "3", name: "Craigieburn", code: "CGE", color: LINE_COLORS.YELLOW },
    { id: "4", name: "Cranbourne", code: "CBE", color: LINE_COLORS.LBLUE },
    { id: "5", name: "Mernda", code: "MND", color: LINE_COLORS.RED },
    { id: "6", name: "Frankston", code: "FKN", color: LINE_COLORS.GREEN },
    { id: "7", name: "Glen Waverley", code: "GWY", color: LINE_COLORS.BLUE },
    { id: "8", name: "Hurstbridge", code: "HBE", color: LINE_COLORS.RED },
    { id: "9", name: "Lilydale", code: "LIL", color: LINE_COLORS.BLUE },
    { id: "11", name: "Pakenham", code: "PKM", color: LINE_COLORS.LBLUE },
    { id: "12", name: "Sandringham", code: "SHM", color: LINE_COLORS.PINK },
    // { id: "13", name: "Stony Point", code: "STY", color: LINE_COLORS.GREEN },
    { id: "14", name: "Sunbury", code: "SUN", color: LINE_COLORS.YELLOW },
    { id: "15", name: "Upfield", code: "UFD", color: LINE_COLORS.YELLOW },
    { id: "16", name: "Werribee", code: "WER", color: LINE_COLORS.GREEN },
    { id: "17", name: "Williamstown", code: "WIL", color: LINE_COLORS.GREEN },
    // { id: "1482", name: "Flemington Racecourse", code: "RCE", color: LINE_COLORS.GREY }
];

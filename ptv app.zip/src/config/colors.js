export const LINE_COLORS = {
    BLUE: 'rgba(1, 81, 138, 1)',
    YELLOW: 'rgba(252, 184, 24, 1)',
    GREEN: 'rgba(0, 150, 69, 1)',
    RED: 'rgba(208, 32, 46, 1)',
    LBLUE: 'rgba(0, 168, 228, 1)',
    PINK: 'rgba(241, 127, 177, 1)',
    GREY: 'rgba(151, 151, 151, 1)',
    ORANGE: 'rgba(235, 130, 0, 1)',
    PURPLE: 'rgba(143, 26, 149, 1)'
};